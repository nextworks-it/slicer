git -c http.sslVerify=false clone master https://github.com/nextworks-it/nfv-ifa-libs.git/$1.git $2

